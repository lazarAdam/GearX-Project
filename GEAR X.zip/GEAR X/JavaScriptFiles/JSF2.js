
var ev1= document.getElementsByClassName("bar-itmes1")[0];
var ev2= document.getElementsByClassName("bar-itmes2")[0];
var ev3= document.getElementsByClassName("bar-itmes3")[0];
var ev4= document.getElementsByClassName("bar-itmes4")[0];
var ev5= document.getElementsByClassName("bar-itmes5")[0];
ev1.addEventListener("click",f1);
ev2.addEventListener("click",f2);
ev3.addEventListener("click",f3);
ev5.addEventListener("click",f4);
var subA =document.getElementById("su1");
var subB =document.getElementById("su2");
var subC =document.getElementById("su3");
var subD =document.getElementById("su4");





var switcher1= false;
var switcher2= false;
var switcher3= false;
var switcher4= false;


function f1(){



	if((ev1.className === "bar-itmes1")&&(switcher1 === false)){
		
		subA.style.visibility="visible";
		subB.style.visibility="hidden";
		subC.style.visibility="hidden";
		subD.style.visibility="hidden";
		document.getElementById("sub1").style.visibility="visible";
		document.getElementById("sub2").style.visibility="hidden";
		document.getElementById("sub3").style.visibility="hidden";
		document.getElementById("sub4").style.visibility="hidden";
		switcher1=true;
		switcher2=false;
		switcher3=false;
		switcher4=false;
		
		}
		else if(switcher1 === true){
		subA.style.visibility="hidden";
		document.getElementById("sub1").style.visibility="hidden";
		switcher1=false;	
		}
}
function f2(){
	
	
	 if((ev2.className === "bar-itmes2")&&(switcher2 === false)){
		
		subB.style.visibility="visible";
		subA.style.visibility="hidden";
		subC.style.visibility="hidden";
		subD.style.visibility="hidden";
		switcher1=false;
		switcher2=true;
		switcher3=false;
		switcher4=false;
		
		document.getElementById("sub2").style.visibility="visible";
		document.getElementById("sub1").style.visibility="hidden";
		document.getElementById("sub3").style.visibility="hidden";
		document.getElementById("sub4").style.visibility="hidden";
	}
	else if(switcher2 === true){
		subB.style.visibility="hidden";
		document.getElementById("sub2").style.visibility="hidden";
		switcher2=false;	
		}
}
function f3(){	

	 if((ev3.className === "bar-itmes3") &&(switcher3 === false)){
		subC.style.visibility="visible";
		subA.style.visibility="hidden";
		subB.style.visibility="hidden";
		subD.style.visibility="hidden";
		document.getElementById("sub3").style.visibility="visible";
		document.getElementById("sub2").style.visibility="hidden";
		document.getElementById("sub1").style.visibility="hidden";
		document.getElementById("sub4").style.visibility="hidden";
		switcher3=true;
		switcher1=false;
		switcher2=false;
		switcher4=false;
	}
	else if(switcher3 === true){
		subC.style.visibility="hidden";
		document.getElementById("sub3").style.visibility="hidden";
		switcher3=false;	
		}
}
function f4(){	


	 if((ev5.className === "bar-itmes5")&&(switcher4 === false)){
		
		subD.style.visibility="visible";
		subA.style.visibility="hidden";
		subB.style.visibility="hidden";
		subC.style.visibility="hidden";
		document.getElementById("sub1").style.visibility="hidden";;
		document.getElementById("sub2").style.visibility="hidden";
		document.getElementById("sub3").style.visibility="hidden";
		document.getElementById("sub4").style.visibility="visible";
		switcher4=true;
		switcher1=false;
		switcher2=false;
		switcher3=false;
		
	}
	else if(switcher4 === true){
		subD.style.visibility="hidden";
		document.getElementById("sub4").style.visibility="hidden";
		switcher4=false;
		}
}
