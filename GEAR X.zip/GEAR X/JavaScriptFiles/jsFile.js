		document.getElementById("checked1").addEventListener("change", hideNshow);
		document.getElementById("checked2").addEventListener("change", hideNshow2);
		document.getElementById("checked3").addEventListener("change", hideNshow3);
		document.getElementById("checked4").addEventListener("change", hideNshow4);
		document.getElementById("checked5").addEventListener("change", hideNshow5);
		document.getElementById("rg").addEventListener("change", range);
		document.getElementsByTagName("button")[0].addEventListener("click", displayPform);
		var e = document.getElementById("ccv");
		e.addEventListener("change",ccvval);
		e.maxLength="3";
		e.size ="3";
	
	
		var totals=0.0;
		var prices=[625.25,399.99,199.55,275.95,120.85];
		var numItmes=0;
		var curvalue= document.getElementById("rg").value;
		
		 

function hideNshow(){
	
	
	
	if(document.getElementById("checked1").checked === true){
		
	for(var i =0; i <2;++i) {
		document.getElementsByClassName("num")[i].style.display = "inline";
		for(var i2 =0; i2 <=3;++i2) 
		document.getElementsByClassName("rad")[i2].style.display = "inline";
	
	}
	document.getElementsByClassName("readp")[1].value = ++numItmes;
	totals+= prices[0]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}
	else{
		for(var j =0; j <2;++j) {
		document.getElementsByClassName("num")[j].style.display = "none";
		for(var j2 =0; j2 <=3;++j2)
		document.getElementsByClassName("rad")[j2].style.display = "none";
	
		}
		document.getElementsByClassName("readp")[1].value = --numItmes;
		totals-=prices[0]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}
	
}
function hideNshow2(){
	
	
	
	if(document.getElementById("checked2").checked === true){
		
	for(var i = 2; i <4;++i) {
		document.getElementsByClassName("num")[i].style.display = "inline";
		for(var i2 =4; i2 <=7;++i2) 
		document.getElementsByClassName("rad")[i2].style.display = "inline";
	
}
	document.getElementsByClassName("readp")[1].value = ++numItmes;
	totals+= prices[1]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}
	else{
		for(var j =2; j <6;++j) {
		document.getElementsByClassName("num")[j].style.display = "none";
		for(var j2 =4; j2 <=7;++j2)
		document.getElementsByClassName("rad")[j2].style.display = "none";
		}
		totals-= prices[1]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
		document.getElementsByClassName("readp")[1].value = --numItmes;
	}
	
}
function hideNshow3(){
	
	
	if(document.getElementById("checked3").checked === true){
		
	for(var i =4; i <6;++i) {
		document.getElementsByClassName("num")[i].style.display = "inline";
		for(var i2 =8; i2 <=16;++i2) 
		document.getElementsByClassName("rad")[i2].style.display = "inline";
	}
	document.getElementsByClassName("readp")[1].value = ++numItmes;
	totals+= prices[2]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}
	else{
		for(var j =4; j <6;++j) {
		document.getElementsByClassName("num")[j].style.display = "none";
		for(var j2 =8; j2 <=16;++j2)
		document.getElementsByClassName("rad")[j2].style.display = "none";
		}
		document.getElementsByClassName("readp")[1].value = --numItmes;
		totals-= prices[2]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}
	
}
function hideNshow4(){
	
	
	if(document.getElementById("checked4").checked === true){
		
	for(var i =6; i <8;++i) {
		document.getElementsByClassName("num")[i].style.display = "inline";
		for(var i2 =17; i2 <=20;++i2) 
		document.getElementsByClassName("rad")[i2].style.display = "inline";
	}
	document.getElementsByClassName("readp")[1].value = ++numItmes;
	totals+= prices[3]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}
	else{
		for(var j =6; j <8;++j) {
		document.getElementsByClassName("num")[j].style.display = "none";
		for(var j2 =17; j2 <=20;++j2)
		document.getElementsByClassName("rad")[j2].style.display = "none";
		}
		document.getElementsByClassName("readp")[1].value = --numItmes;
		totals-= prices[3]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}	
}
function hideNshow5(){
	
	
	if(document.getElementById("checked5").checked === true){
		
	for(var i =8; i <10;++i) {
		document.getElementsByClassName("num")[i].style.display = "inline";
		for(var i2 =21; i2 <=24;++i2) 
		document.getElementsByClassName("rad")[i2].style.display = "inline";
	}
	document.getElementsByClassName("readp")[1].value = ++numItmes;
	totals+= prices[4]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
	}
	else{
		for(var j =8; j <10;++j) {
		document.getElementsByClassName("num")[j].style.display = "none";
		for(var j2 =21; j2 <=24;++j2)
		document.getElementsByClassName("rad")[j2].style.display = "none";
		  }
		  
		  document.getElementsByClassName("readp")[1].value = --numItmes;
		  totals-= prices[4]; document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);
		  
	}	
}

function displayPform(){
	
	
	document.getElementById("purform").style.display = "inline";
	document.getElementById("tdup").value = "$"+totals.toFixed(2);
	
	 /*var x = document.getElementsByTagName("fieldset");
	for(var i = 0; i<6;++i)
		x[i].style.display = "none";*/
}

function extra$(amount){
	
	
	 var x = parseInt(amount);
	
 
	totals+= x;
	
	
	document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);	
}
function range(){
	
	document.getElementById("txt2").innerHTML;
	
	
	
	if( document.getElementById("rg").value > curvalue){
		 ++curvalue;
			
			totals+=60;
	 
	}
	else if (document.getElementById("rg").value<curvalue){
	--curvalue;
		totals-=60;
}
if(curvalue == 1){
	document.getElementById("txt2").innerHTML="120GB";
}

else if(curvalue == 2){
	
	document.getElementById("txt2").innerHTML="250GB";
	
}
	else if (curvalue ==3){
		
		document.getElementById("txt2").innerHTML="500gb";
	}
		else if (curvalue ==4){
			
			document.getElementById("txt2").innerHTML="1TB";
		}
			
	
	document.getElementsByClassName("readt")[1].value = "$"+totals.toFixed(2);	
}
function ccvval(){
	
	var v = document.getElementById("ccv");
	var tx= document.getElementById("ccvTxt");
	if(v.value%16!=0){
		
		tx.innerHTML="invalid input";
		
		v.value=null;
	}
		else
			tx.innerHTML=null;
			return;
	
	
	
}